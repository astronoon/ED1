#include <stdio.h>
#include <stdlib.h>
#include "Stack.h"

int main() {
    Stack *p = create_stack();
    char token[50];

    //leitura de expressão polonesa
    while (scanf("%s", token) != EOF) {
        //checa se o primeiro caractere é número
        if (token[0] >= '0' && token[0] <= '9') {
            int num = atoi(token);
            push(p, num);
        } 
        //caso contrário, é operador
        else {
            int a, b;
            pop(p, &b); 
            pop(p, &a); 

            //realiza operação
            int res = 0;
            switch (token[0]) {
                case '+': res = a + b; break;
                case '-': res = a - b; break;
                case '*': res = a * b; break;
                case '/': res = a / b; break;
                default:
                    free_stack(&p);
                    return 1;
            }
            push(p, res);
        }
    }

    //imprime resultado final
    int resultado;
    pop(p, &resultado);
    printf("%d\n", resultado);

    //libera memória
    free_stack(&p);
    return 0;
}
