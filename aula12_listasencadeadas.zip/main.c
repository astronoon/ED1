#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"

// Programa de teste para TAD LinkedList
int main() {
    int x, p, value;

    // criação de duas listas
    LinkedList *l1 = create_linked_list();
    LinkedList *l2 = create_linked_list();

    // leitura de valores e inserção em l1
    printf("Digite pares (valor, posicao). Posicao negativa para parar:\n");
    while (1) {
        scanf("%d %d", &x, &p);
        if (p < 0) break;
        insert_node(l1, p, x);   // insere elemento na posição p
    }

    // leitura de valores e remoção de l1
    printf("Digite posicoes para remover. Posicao negativa para parar:\n");
    while (1) {
        scanf("%d", &p);
        if (p < 0) break;
        if (remove_node(l1, p, &value))
            printf("Removido: %d\n", value);
        else
            printf("Falha ao remover na posicao %d\n", p);
    }

    // exemplo de uso de get_node
    printf("Digite posicoes para consultar. Posicao negativa para parar:\n");
    while (1) {
        scanf("%d", &p);
        if (p < 0) break;
        if (get_node(l1, p, &value))
            printf("Valor na posicao %d: %d\n", p, value);
        else
            printf("Posicao %d invalida\n", p);
    }

    // libera memória
    free_linked_list(&l1);
    free_linked_list(&l2);

    return 0;
}
