#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"

int main() {
    Queue *fila1 = create_queue();
    Queue *fila2 = create_queue();

    int comando, valor;
    while (scanf("%d", &comando) == 1) {
        if (comando == 0) {
            break;
        } else if (comando == 1) {
            if (scanf("%d", &valor) == 1) {
                enqueue(fila1, valor);
            }
        } else if (comando == 2) {
            if (scanf("%d", &valor) == 1) {
                enqueue(fila2, valor);
            }
        } else if (comando == 3) {
            for (int i = 0; i < 3; i++) {
                int removido;
                int r = 0;
                if (i < 2) {
                    r = dequeue(fila2, &removido);
                    if (!r) r = dequeue(fila1, &removido);
                } else {
                    r = dequeue(fila1, &removido);
                    if (!r) r = dequeue(fila2, &removido);
                }
                if (r == 1) {
                    printf("%d\n", removido);
                    fflush(stdout);  // força saída imediata
                }
            }
        }
    }

    free_queue(&fila1);
    free_queue(&fila2);
    return 0;
}
