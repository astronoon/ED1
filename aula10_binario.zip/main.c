/*Programa em C que faz conversão decimal 
para binário usando nosso TAD pilha*/

#include <stdio.h>
#include <stdlib.h>
#include "Stack.h" 

//funcao que converte decimal para binario
void decimal_para_binario(int n) {
    //cria pilha
    Stack *p = create_stack();

    //enquanto houver número para dividir
    while (n > 0) {
        //empilha o resto
        push(p, n % 2);
        //atualiza o quociente
        n = n / 2;
    }

    //imprime o binário na ordem certa
    while (!is_empty(p)) {
        int valor;
        pop(p, &valor);  // remove o topo e guarda em valor
        printf("%d", valor);
    }

    //libera a memoria
    free_stack(&p);
}

int main() {
    //variavel
    int numero;

    //entrada
    scanf("%d", &numero);
    
    //saida
    decimal_para_binario(numero);
    printf("\n");

    return 0;
}