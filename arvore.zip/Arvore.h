#ifndef ARVORE_H
#define ARVORE_H

/* TAD Árvore binária como ponteiro opaco */
typedef struct No* Arvore;

/* Cria um nó com valor e filhos dados. Retorna NULL em falha. */
Arvore arv_cria(int valor, Arvore esq, Arvore dir);

/* Libera toda a árvore recursivamente. Aceita NULL. */
void arv_libera(Arvore r);

/* Retorna 1 se vazia, 0 caso contrário. */
int arv_vazia(Arvore r);

/* Retorna o número de nós. */
int arv_tamanho(Arvore r);

/* Retorna a altura. */
int arv_altura(Arvore r);

/* Inserção em Árvore Binária de Busca */
Arvore arv_insere(Arvore r, int v);

/* Percursos em profundidade */
void arv_preordem(Arvore r);  
void arv_inordem(Arvore r);   
void arv_posordem(Arvore r);  

/* Percurso em largura */
void arv_largura(Arvore r);

#endif /* ARVORE_H */
