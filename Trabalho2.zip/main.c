/*Integrante:
Bruna Rafaela de Souza Weber - 15744172*/

/*Trabalho 2 - programa operacoes aritmeticas e comparacoes entre numeros
inteiros de tamanho arbitrario. Esses numeros deverão ser representados utilizando
uma lista encadeada, na qual cada no da lista armazenara um bloco de digitos do numero.
Dessa forma, o programa deve permitir somar e comparar numeros de qualquer comprimento.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "numero.h"

int main() {

//variaveis
int operacoes;
char linha[1000];

//entrada da quantidade de operacoes
if (scanf("%d", &operacoes) != 1) {
    return 0;
}
fgets(linha, sizeof(linha), stdin);

//variavel de controle
int i = 0;

//executa as operacoes (loop principal de leitura e execucao)
while (i < operacoes) {

    //leitura da linha
    if (fgets(linha, sizeof(linha), stdin) == NULL) {
        break;
    }

    //remove '\r' e '\n' do final
    size_t len = strlen(linha);
    if (len > 0 && (linha[len - 1] == '\n' || linha[len - 1] == '\r')) {
        linha[--len] = '\0';
    }
    if (len > 0 && linha[len - 1] == '\r') {
        linha[--len] = '\0';
    }

    //verifica se a linha esta vazia
    if (len == 0) {

        //volta o contador para repetir a operacao
        i--;

    } else {

        //variavel de controle
        int j = 0;

        //ignora espacos em branco antes do comando
        while (linha[j] == ' ') {
            j++;
        }

        //variaveis auxiliares
        char num1[500] = {0};
        char num2[500] = {0};
        int k = 0;
        Numero *a, *b, *s;
        int resultado;

        //operacao de soma
        if (strncmp(&linha[j], "soma", 4) == 0) {

            //pula para o primeiro numero
            j += 4;
            while (linha[j] == ' ') {
                j++;
            }

            //le o primeiro numero
            k = 0;
            while (linha[j] != ' ' && linha[j] != '\0') {
                num1[k++] = linha[j++];
            }
            num1[k] = '\0';

            //pula espacos entre os numeros
            while (linha[j] == ' ') {
                j++;
            }

            //le o segundo numero
            k = 0;
            while (linha[j] != '\0' && linha[j] != '\n') {
                num2[k++] = linha[j++];
            }
            num2[k] = '\0';

            //cria numeros a partir das strings
            a = criarNumero(num1);
            b = criarNumero(num2);

            //soma os numeros
            s = somar(a, b);

            //imprime resultado
            printf("Resultado :: ");
            imprimirNumero(s);
            printf("\n");

            //libera memoria
            liberarNumero(a);
            liberarNumero(b);
            liberarNumero(s);
        }

        //operacao de comparacao: maior
        else if (strncmp(&linha[j], "maior", 5) == 0) {

            //pula para o primeiro numero
            j += 5;
            while (linha[j] == ' ') {
                j++;
            }

            //le o primeiro numero
            k = 0;
            while (linha[j] != ' ' && linha[j] != '\0') {
                num1[k++] = linha[j++];
            }
            num1[k] = '\0';

            //pula espacos entre os numeros
            while (linha[j] == ' ') {
                j++;
            }

            //le o segundo numero
            k = 0;
            while (linha[j] != '\0' && linha[j] != '\n') {
                num2[k++] = linha[j++];
            }
            num2[k] = '\0';

            //cria numeros
            a = criarNumero(num1);
            b = criarNumero(num2);

            //compara os numeros
            resultado = comparar(a, b);

            //imprime resultado
            printf("Resultado :: ");
            if (resultado == 1) {
                printf("True\n");
            } else {
                printf("False\n");
            }

            //libera memoria
            liberarNumero(a);
            liberarNumero(b);
        }

        //operacao de comparacao: menor
        else if (strncmp(&linha[j], "menor", 5) == 0) {

            //pula para o primeiro numero
            j += 5;
            while (linha[j] == ' ') {
                j++;
            }

            //le o primeiro numero
            k = 0;
            while (linha[j] != ' ' && linha[j] != '\0') {
                num1[k++] = linha[j++];
            }
            num1[k] = '\0';

            //pula espacos entre os numeros
            while (linha[j] == ' ') {
                j++;
            }

            //le o segundo numero
            k = 0;
            while (linha[j] != '\0' && linha[j] != '\n') {
                num2[k++] = linha[j++];
            }
            num2[k] = '\0';

            //cria numeros
            a = criarNumero(num1);
            b = criarNumero(num2);

            //compara os numeros
            resultado = comparar(a, b);

            //imprime resultado
            printf("Resultado :: ");
            if (resultado == -1) {
                printf("True\n");
            } else {
                printf("False\n");
            }

            //libera memoria
            liberarNumero(a);
            liberarNumero(b);
        }

        //operacao de comparacao: igual
        else if (strncmp(&linha[j], "igual", 5) == 0) {
            //pula para o primeiro numero
            j += 5;
            while (linha[j] == ' ') {
                j++;
            }

            //le o primeiro numero
            k = 0;
            while (linha[j] != ' ' && linha[j] != '\0') {
                num1[k++] = linha[j++];
            }
            num1[k] = '\0';

            //pula espacos entre os numeros
            while (linha[j] == ' ') {
                j++;
            }

            //le o segundo numero
            k = 0;
            while (linha[j] != '\0' && linha[j] != '\n') {
                num2[k++] = linha[j++];
            }
            num2[k] = '\0';

            //cria numeros
            a = criarNumero(num1);
            b = criarNumero(num2);

            //compara os numeros
            resultado = comparar(a, b);

            //imprime resultado
            printf("Resultado :: ");
            if (resultado == 0) {
                printf("True\n");
            } else {
                printf("False\n");
            }

            //libera memoria
            liberarNumero(a);
            liberarNumero(b);
        }
    }

    //incrementa o contador de operacoes
    i++;
}

return 0;

}
