#include <stdio.h>
#include <stdlib.h>
#include "Arvore.h"

struct No {
    int valor;
    struct No *esq;
    struct No *dir;
};

/* Cria um nó com valor e filhos dados. Retorna NULL em falha. */
Arvore arv_cria(int valor, Arvore esq, Arvore dir) {
    Arvore r = malloc(sizeof(struct No));
    if (!r) return NULL;

    r->valor = valor;
    r->esq = esq;
    r->dir = dir;

    return r;
}

/* Libera toda a árvore recursivamente. */
void arv_libera(Arvore r) {
    if (!r) return;
    arv_libera(r->esq);
    arv_libera(r->dir);
    free(r);
}

/* Retorna 1 se vazia, 0 caso contrário. */
int arv_vazia(Arvore r) {
    return (r == NULL);
}

/* Retorna o número de nós. */
int arv_tamanho(Arvore r) {
    if (r == NULL) return 0;
    return 1 + arv_tamanho(r->esq) + arv_tamanho(r->dir);
}

/* Retorna a altura (vazia = -1, folha = 0). */
int arv_altura(Arvore r) {
    if (!r) return -1;
    int ae = arv_altura(r->esq);
    int ad = arv_altura(r->dir);
    return 1 + (ae > ad ? ae : ad);
}

/* Inserção em ABB */
Arvore arv_insere(Arvore r, int v) {
    if (r == NULL) {
        return arv_cria(v, NULL, NULL);
    }
    if (v < r->valor) {
        r->esq = arv_insere(r->esq, v);
    } else {
        r->dir = arv_insere(r->dir, v);
    }
    return r;
}

/* Percursos */
void arv_preordem(Arvore r) {
    if (!r) return;
    printf("%d ", r->valor);
    arv_preordem(r->esq);
    arv_preordem(r->dir);
}

void arv_inordem(Arvore r) {
    if (!r) return;
    arv_inordem(r->esq);
    printf("%d ", r->valor);
    arv_inordem(r->dir);
}

void arv_posordem(Arvore r) {
    if (!r) return;
    arv_posordem(r->esq);
    arv_posordem(r->dir);
    printf("%d ", r->valor);
}

/* Percurso em largura (não usado no exercício, mas mantido) */
void arv_largura(Arvore r) {
    if (!r) return;

    int n = arv_tamanho(r);
    Arvore* fila = malloc(n * sizeof(Arvore));
    int ini = 0, fim = 0;

    fila[fim++] = r;

    while (ini < fim) {
        Arvore u = fila[ini++];
        printf("%d ", u->valor);

        if (u->esq) fila[fim++] = u->esq;
        if (u->dir) fila[fim++] = u->dir;
    }

    free(fila);
}
