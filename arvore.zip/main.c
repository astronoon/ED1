#include <stdio.h>
#include "Arvore.h"

int main() {
    int N;
    scanf("%d", &N);

    Arvore raiz = NULL;

    for (int i = 0; i < N; i++) {
        int x;
        scanf("%d", &x);
        raiz = arv_insere(raiz, x);
    }

    // pré ordem
    arv_preordem(raiz);
    printf("\n");

    // em ordem
    arv_inordem(raiz);
    printf("\n");

    // pós ordem
    arv_posordem(raiz);
    printf("\n");

    // altura pedida pelo enunciado
    int h = arv_altura(raiz) + 1;
    printf("%d\n", h);

    arv_libera(raiz);
    return 0;
}
