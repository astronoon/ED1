#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "numero.h"

//define o tamanho do bloco de digitos
#define K 4

//funcao que cria um no da lista
Lista *novaLista(int valor) {
//aloca memoria para um novo no
Lista *n = (Lista *) malloc(sizeof(Lista));
if (n == NULL) {
return NULL;
}

n->bloco = valor;
n->ant = NULL;
n->prox = NULL;
return n;

}

//funcao que insere um bloco no inicio da lista
void inserirInicio(Numero *num, int bloco) {
//cria um novo no com o valor do bloco
Lista *n = novaLista(bloco);
if (n == NULL) {
return;
}

//verifica se a lista esta vazia
if (num->inicio == NULL) {
    num->inicio = n;
    num->fim = n;
} else {
    //atualiza encadeamento para inserir no comeco
    n->prox = num->inicio;
    num->inicio->ant = n;
    num->inicio = n;
}

}

//funcao que insere um bloco no fim da lista
void inserirFim(Numero *num, int bloco) {
//cria um novo no com o valor do bloco
Lista *n = novaLista(bloco);
if (n == NULL) {
return;
}

//verifica se a lista esta vazia
if (num->fim == NULL) {
    num->inicio = n;
    num->fim = n;
} else {
    //liga o novo no ao final da lista
    n->ant = num->fim;
    num->fim->prox = n;
    num->fim = n;
}

}

//funcao auxiliar que remove zeros a esquerda
void removerZerosEsquerda(Numero *num) {
//remove todos os zeros iniciais mantendo pelo menos um elemento
while (num->inicio != NULL && num->inicio->bloco == 0 && num->inicio->prox != NULL) {
Lista *tmp = num->inicio;
num->inicio = num->inicio->prox;
num->inicio->ant = NULL;
free(tmp);
}
}

//funcao que cria um numero a partir de uma string
Numero *criarNumero(char *str) {
//aloca estrutura Numero
Numero *num = (Numero *) malloc(sizeof(Numero));
if (num == NULL) {
return NULL;
}

num->inicio = NULL;
num->fim = NULL;
num->negativo = 0;

int i = 0;
int len = strlen(str);

//remove caractere de nova linha se existir
if (len > 0 && str[len - 1] == '\n') {
    str[len - 1] = '\0';
    len--;
}

//verifica se o numero e negativo
if (str[0] == '-') {
    num->negativo = 1;
    i = 1;
}

//ignora zeros a esquerda na string
while (i < len && str[i] == '0') {
    i++;
}

//caso o numero seja 0
if (i == len) {
    inserirInicio(num, 0);
    return num;
}

//processa blocos de K digitos da direita para a esquerda
int end = len - 1;
while (end >= i) {
    int start = end - K + 1;
    if (start < i) {
        start = i;
    }

    //converte o bloco manualmente
    int bloco = 0;
    int multiplicador = 1;

    for (int j = end; j >= start; j--) {
        bloco += (str[j] - '0') * multiplicador;
        multiplicador *= 10;
    }

    //insere bloco convertido na lista
    inserirInicio(num, bloco);
    end = start - 1;
}

return num;

}

//funcao que libera memoria de um numero
void liberarNumero(Numero *num) {
//percorre e libera todos os nos da lista
Lista *atual = num->inicio;
while (atual != NULL) {
Lista *tmp = atual->prox;
free(atual);
atual = tmp;
}

//libera a estrutura principal
free(num);
}

//funcao auxiliar que copia um numero
Numero *copiarNumero(Numero *orig) {
//aloca novo Numero
Numero *novo = (Numero *) malloc(sizeof(Numero));
if (novo == NULL) {
return NULL;
}

novo->inicio = NULL;
novo->fim = NULL;
novo->negativo = orig->negativo;

//percorre lista e copia cada bloco
for (Lista *p = orig->inicio; p != NULL; p = p->prox) {
    inserirFim(novo, p->bloco);
}

return novo;

}

//funcao auxiliar que subtrai dois numeros positivos
//importante a >= b
Numero *subtrairPositivos(Numero *a, Numero *b) {
//aloca resultado
Numero *res = (Numero *) malloc(sizeof(Numero));
if (res == NULL) {
return NULL;
}

res->inicio = NULL;
res->fim = NULL;
res->negativo = 0;

Lista *pa = a->fim;
Lista *pb = b->fim;
int emprestimo = 0;

//subtracao bloco a bloco da direita
while (pa != NULL || pb != NULL) {
    int va;
    if (pa != NULL) {
        va = pa->bloco;
    } else {
        va = 0;
    }

    int vb;
    if (pb != NULL) {
        vb = pb->bloco;
    } else {
        vb = 0;
    }

    int sub = va - vb - emprestimo;
    if (sub < 0) {
        sub += 10000;
        emprestimo = 1;
    } else {
        emprestimo = 0;
    }

    //insere bloco resultante
    inserirInicio(res, sub);

    if (pa != NULL) {
        pa = pa->ant;
    }
    if (pb != NULL) {
        pb = pb->ant;
    }
}

//remove zeros excedentes apos operacao
removerZerosEsquerda(res);
return res;

}

//funcao que compara dois numeros grandes
int comparar(Numero *a, Numero *b) {
//comparacao de sinais
if (a->negativo && !b->negativo) {
return -1;
}
if (!a->negativo && b->negativo) {
return 1;
}

//conta blocos em cada numero
int count_a = 0;
int count_b = 0;
Lista *temp_a = a->inicio;
Lista *temp_b = b->inicio;

while (temp_a != NULL) {
    count_a++;
    temp_a = temp_a->prox;
}

while (temp_b != NULL) {
    count_b++;
    temp_b = temp_b->prox;
}

//compara tamanhos
if (count_a > count_b) {
    if (a->negativo) {
        return -1;
    } else {
        return 1;
    }
}

if (count_a < count_b) {
    if (a->negativo) {
        return 1;
    } else {
        return -1;
    }
}

//compara blocos na ordem
Lista *pa = a->inicio;
Lista *pb = b->inicio;
while (pa != NULL && pb != NULL) {
    if (pa->bloco > pb->bloco) {
        if (a->negativo) {
            return -1;
        } else {
            return 1;
        }
    }

    if (pa->bloco < pb->bloco) {
        if (a->negativo) {
            return 1;
        } else {
            return -1;
        }
    }

    pa = pa->prox;
    pb = pb->prox;
}

return 0;

}

//funcao que realiza a soma de dois numeros
Numero *somar(Numero *a, Numero *b) {
//caso ambos positivos
if (!a->negativo && !b->negativo) {
//aloca estrutura resultado
Numero *res = (Numero *) malloc(sizeof(Numero));
if (res == NULL) {
return NULL;
}

    res->inicio = NULL;
    res->fim = NULL;
    res->negativo = 0;

    Lista *pa = a->fim;
    Lista *pb = b->fim;
    int carry = 0;

    //soma bloco a bloco com transporte
    while (pa != NULL || pb != NULL || carry != 0) {
        int va;
        if (pa != NULL) {
            va = pa->bloco;
        } else {
            va = 0;
        }

        int vb;
        if (pb != NULL) {
            vb = pb->bloco;
        } else {
            vb = 0;
        }

        int soma = va + vb + carry;
        carry = soma / 10000;
        soma = soma % 10000;

        inserirInicio(res, soma);

        if (pa != NULL) {
            pa = pa->ant;
        }
        if (pb != NULL) {
            pb = pb->ant;
        }
    }

    removerZerosEsquerda(res);
    return res;
}

//caso ambos negativos
if (a->negativo && b->negativo) {
    //copia sem sinal
    Numero *a_pos = copiarNumero(a);
    Numero *b_pos = copiarNumero(b);
    if (a_pos == NULL || b_pos == NULL) {
        return NULL;
    }

    a_pos->negativo = 0;
    b_pos->negativo = 0;

    //soma positivos
    Numero *res = somar(a_pos, b_pos);
    res->negativo = 1;

    liberarNumero(a_pos);
    liberarNumero(b_pos);
    return res;
}

//sinais diferentes a negativo b positivo
if (a->negativo && !b->negativo) {
    Numero *a_pos = copiarNumero(a);
    if (a_pos == NULL) {
        return NULL;
    }
    a_pos->negativo = 0;

    if (comparar(a_pos, b) > 0) {
        Numero *res = subtrairPositivos(a_pos, b);
        res->negativo = 1;
        liberarNumero(a_pos);
        return res;
    } else {
        Numero *res = subtrairPositivos(b, a_pos);
        res->negativo = 0;
        liberarNumero(a_pos);
        return res;
    }
}

//sinais diferentes a positivo b negativo
if (!a->negativo && b->negativo) {
    Numero *b_pos = copiarNumero(b);
    if (b_pos == NULL) {
        return NULL;
    }
    b_pos->negativo = 0;

    if (comparar(a, b_pos) >= 0) {
        Numero *res = subtrairPositivos(a, b_pos);
        res->negativo = 0;
        liberarNumero(b_pos);
        return res;
    } else {
        Numero *res = subtrairPositivos(b_pos, a);
        res->negativo = 1;
        liberarNumero(b_pos);
        return res;
    }
}

return NULL;

}

//funcao que imprime o numero
void imprimirNumero(Numero *num) {
//verifica se o numero e zero
int ehZero;
if (num->inicio == NULL) {
ehZero = 1;
} else if (num->inicio->bloco == 0 && num->inicio->prox == NULL) {
ehZero = 1;
} else {
ehZero = 0;
}

//imprime sinal se necessario
if (num->negativo && !ehZero) {
    printf("-");
}

Lista *p = num->inicio;
if (p == NULL) {
    printf("0");
    return;
}

//imprime primeiro bloco sem zeros a esquerda
printf("%d", p->bloco);
p = p->prox;

//imprime demais blocos com 4 digitos
while (p != NULL) {
    printf("%04d", p->bloco);
    p = p->prox;
}

}