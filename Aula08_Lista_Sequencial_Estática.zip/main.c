/*Programa em C com Tipo Abstrato de Dados (TAD) 
para uma Lista Sequencial Estática, a main com um 
menu de operações sobre a lista, que apenas leia 
e execute as opções*/

#include <stdio.h>
#include <stdlib.h>
#include "LSE.h"

int main() {
    //variáveis
    LSE *l = lse_cria();
    int opcao, posicao, elemento, valor, pos;

    //entrada
    while (scanf("%d", &opcao) != EOF) {
        if (opcao == 9) {
            break;
        }

        //menu
        switch (opcao) {
            //insere no final
            case 1: 
                scanf("%d", &elemento);
                printf("%d\n", lse_insere_final(l, elemento));
                break;

            //insere na posição
            case 2:
                scanf("%d %d", &posicao, &elemento);
                printf("%d\n", lse_insere_pos(l, posicao, elemento));
                break;

            //remove a posição
            case 3:
                scanf("%d", &posicao);
                int ret = lse_remove_pos(l, posicao, &valor);
                if (ret == 1) {
                    printf("%d\n", valor);
                } else {
                    printf("ERRO\n");
                }
                break;

            //consulta a posição
            case 4:
            scanf("%d", &posicao);
            ret = lse_consulta_pos(l, posicao, &valor);
            if (ret == 1) {
                printf("%d\n", valor);
            } else {
                printf("ERRO\n");
            }
            break;
            
            //busca o elemento
            case 5:
                scanf("%d", &elemento);
                if (lse_busca(l, elemento, &pos)) {
                    printf("%d\n", pos);
                } else {
                    printf("-1\n");
                }
                break;

            //imprime o tamanho
            case 6:
                printf("%d\n", lse_tamanho(l));
                break;

            //imprime a lista
            case 7:
                lse_imprime(l);
                break;

            //limpa a lista
            case 8:
                lse_limpa(l);
                break;
        }
    }

    //libera memória
    lse_destroi(&l);
    return 0;
}
