#ifndef DEQUE_H
#define DEQUE_H

typedef struct deque Deque;

Deque* create_deque(void);
int is_empty(const Deque *dq);
int is_full(const Deque *dq);
int size(const Deque *dq);

/* inserção e remoção nas duas pontas */
int push_front(Deque *dq, int value);
int push_back(Deque *dq, int value);
int pop_front(Deque *dq, int *value);
int pop_back(Deque *dq, int *value);

/* acesso sem remover */
int front(const Deque *dq, int *value);
int back(const Deque *dq, int *value);

/* liberação segura */
void free_deque(Deque **dq);

#endif
