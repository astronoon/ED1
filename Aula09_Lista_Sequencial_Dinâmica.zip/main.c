/*Programa em C com Tipo Abstrato de Dados (TAD) 
para uma Lista Sequencial Dinamica, a main com um 
menu de operações sobre a lista, que apenas leia 
e execute as opções*/

#include <stdio.h>
#include <stdlib.h>
#include "LSD.h"

int main() {
    // cria a lista
    LSD *l = lsd_cria();
    int opcao, posicao, elemento, valor, pos;
    int ret;

    // leitura das operações
    while (scanf("%d", &opcao) != EOF) {
        if (opcao == 9) {
            break; // encerra o programa
        }

        switch (opcao) {
            //insere no final
            case 1: 
                scanf("%d", &elemento);
                printf("%d\n", lsd_insere_final(l, elemento));
                break;

            //insere na posição
            case 2:
                scanf("%d %d", &posicao, &elemento);
                printf("%d\n", lsd_insere_pos(l, posicao, elemento));
                break;

            //remove da posição
            case 3:
                scanf("%d", &posicao);
                ret = lsd_remove_pos(l, posicao, &valor);
                if (ret == 1) {
                    printf("%d\n", valor);
                } else {
                    printf("ERRO\n");
                }
                break;

            //consulta a posição
            case 4:
                scanf("%d", &posicao);
                ret = lsd_consulta_pos(l, posicao, &valor);
                if (ret == 1) {
                    printf("%d\n", valor);
                } else {
                    printf("ERRO\n");
                }
                break;

            //busca elemento
            case 5:
                scanf("%d", &elemento);
                if (lsd_busca(l, elemento, &pos)) {
                    printf("%d\n", pos);
                } else {
                    printf("-1\n");
                }
                break;

            //imprime tamanho
            case 6:
                printf("%d\n", lsd_tamanho(l));
                break;

            //imprime lista
            case 7:
                lsd_imprime(l);
                break;

            //limpa lista
            case 8:
                lsd_limpa(l);
                break;
        }
    }

    //libera memória
    lsd_destroi(&l);
    return 0;
}
