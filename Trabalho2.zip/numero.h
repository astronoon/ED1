#ifndef NUMERO_H
#define NUMERO_H

//definicao da estrutura lista
typedef struct Lista {
    int bloco;
    struct Lista *ant;
    struct Lista *prox;
} Lista;

//definicao da estrutura numero
typedef struct {
    Lista *inicio;
    Lista *fim;
    int negativo;
} Numero;

//definicao das funcoes
Numero *criarNumero(char *str);
void liberarNumero(Numero *num);
Numero *somar(Numero *a, Numero *b);
int comparar(Numero *a, Numero *b);
void imprimirNumero(Numero *num);

#endif
