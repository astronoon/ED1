/* menu de operacoes para representar 
pontos no plano cartesiano em C*/

#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"

int main() {
    //variaveis
    float x1, x2, y1, y2;

    //primeira entrada
    if (scanf("%f %f", &x1, &y1) != 2) {
        printf("Entrada inválida!\n");
        return 1;
    }
    
    //segunda entrada
    if (scanf("%f %f", &x2, &y2) != 2) {
        printf("Entrada inválida!\n");
        return 1;
    }

    //cria os pontos
    Ponto *P1 = criaPonto(x1, y1);
    Ponto *P2 = criaPonto(x2, y2);

    //variavel para o menu
    int escolha = 0;
    //menu
    while (escolha != 9) { 
        if (scanf("%d", &escolha) != 1) {
            //limpa o buffer de entrada
            int c; while ((c = getchar()) != '\n' && c != EOF);
            continue;
        }

        switch (escolha) {
            case 1:
                imprimePonto(P1);
                break;
            case 2:
                imprimePonto(P2);
                break;
            case 3:
                printf("%.3f\n", distancia(P1, P2));
                break;
            case 4:
                printf("%.3f\n", distanciaOrigem(P1));
                break;
            case 5:
                printf("%.3f\n", distanciaOrigem(P2));
                break;
            case 6:
                if (scanf("%f %f", &x1, &y1) != 2) {
                    int c; while ((c = getchar()) != '\n' && c != EOF);
                    break;
                }
                atribuiPonto(P1, x1, y1);
                break;
            case 7:
                if (scanf("%f %f", &x2, &y2) != 2) {
                    int c; while ((c = getchar()) != '\n' && c != EOF);
                    break;
                }
                atribuiPonto(P2, x2, y2);
                break;
            case 8:
                printf("%d\n", pontosIguais(P1, P2));
                break;
            case 9:
                //encerra o loop
                break;
            default:
                //invalido
                break;
        }
    }

    //libera os pontos
    liberaPonto(P1);
    liberaPonto(P2);
    return 0;
}
